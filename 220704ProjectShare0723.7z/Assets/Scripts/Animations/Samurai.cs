using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Samurai : MonoBehaviour
{

    [SerializeField] GameObject Enemy;
    [SerializeField] float jumpForce = 6f;

    private Animator anim;
    private BoxCollider2D col;
    private Rigidbody2D rigid;

    private float horizontal;

    private bool isGrounded;

    private bool isDead;

    private void Awake()
    {
        anim = GetComponent<Animator>();
        col = GetComponent<BoxCollider2D>();
        rigid = GetComponent<Rigidbody2D>();

        //EventManager.AddEvent("Player :: SetDie", (p) =>
        //{
        //    anim.SetTrigger("SetDie");
        //    isDead = true;
        //});
    }

    private void Update()
    {
        CheckGrounded();
        if (!isDead)
        {
            PlayerMove();
        }
    }

    private void CheckGrounded()
    {
        RaycastHit2D hit = Physics2D.Raycast(
            col.bounds.center,
            Vector2.down,
            col.bounds.extents.y + .02f,
            ~(1 << LayerMask.NameToLayer("Player")));
        isGrounded = (hit.collider != null);
    }

    private void PlayerMove()
    {
        //horizontal = Input.GetAxis("Horizontal");

        //anim.SetFloat("speed", Mathf.Abs(horizontal));
        //anim.SetBool("Air", !isGrounded);

        //rigid.velocity = new Vector3(horizontal * 5f, rigid.velocity.y);

        //if (horizontal < 0)
        //{
        //    transform.localScale = new Vector3(-3, 3, 3);
        //}
        //else if (horizontal > 0)
        //{
        //    transform.localScale = new Vector3(3, 3, 3);
        //}


        if (Input.GetButtonDown("Jump") && isGrounded)
        {
            anim.SetTrigger("Jump");
            isGrounded = false;
            rigid.velocity = new Vector2(rigid.velocity.x, jumpForce);

        }


    }

    public void OnTriggerEnter2D(Collider2D collision)
    {
       if(collision.CompareTag("Enemy"))
        {
            anim.SetTrigger("Contact");
            Debug.Log("���� ����!");
            Enemy.SetActive (false);
            
        }
    }
}
