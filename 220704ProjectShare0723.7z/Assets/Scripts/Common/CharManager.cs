using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CharManager 
{
    public static List<CharData> data = new List<CharData>();
    public static CharData GetChar(string charCode) => data.Find(e => e.charCode == charCode);
    public static void AddChar(CharData charData) => data.Add(charData);


}
