using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameManager : MonoBehaviour
{
    private void Awake()
    {
        CharManager.AddChar(new CharData("0000", "Choco", "chocochoco", 1000,  "getCHoco"));
        CharManager.AddChar(new CharData("0001", "Choco1", "chocochoco1", 10001, "getCHoco1"));
        CharManager.AddChar(new CharData("0002", "Choco2", "chocochoco2", 10002, "getCHoco2"));
        CharManager.AddChar(new CharData("0003", "Choco3", "chocochoco3", 10003, "getCHoco3"));
        CharManager.AddChar(new CharData("0004", "Choco4", "chocochoco4", 10004, "getCHoco4"));
        CharManager.AddChar(new CharData("0005", "Choco5", "chocochoco5", 10005, "getCHoco5"));
    }
}
