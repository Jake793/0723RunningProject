using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class IngameSceneController : MonoBehaviour
{
    public void SceneIngame()
    {
        SceneManager.LoadScene("Ingame Scene");
    }


    public void SceneMain()
    {
        SceneManager.LoadScene("Main Scene");
    }
}
