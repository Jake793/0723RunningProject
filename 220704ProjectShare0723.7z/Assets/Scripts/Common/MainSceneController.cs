using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;
using UnityEngine.SceneManagement;

public class MainSceneController : MonoBehaviour
{
    public bool isMain = true;
    public bool isCharSelect = false;
    public bool isShop = false;
    public bool isConfirm = false;
    public bool isMail = false;
    public bool isSetting = false;


    int maxRanNum;
    public int bestScore = 10000;

    int confirmNum;


    bool shopfinish = false;
    public bool reset = false;



    

    [SerializeField] GameObject charSelectUI;
    [SerializeField] GameObject shopUI;
    [SerializeField] GameObject confirmUI;
    [SerializeField] GameObject mailUI;
    [SerializeField] GameObject settingUI;
    [SerializeField] GameObject mailParent;
    [SerializeField] GameObject eventParent;

    [SerializeField] Text levelTxt;
    [SerializeField] Text nameTxt;
    [SerializeField] Text goldTxt;



    [SerializeField] Image currentCharImgPos;


    Sprite currentCharImg;
    
    [SerializeField] GameObject mainShadow;
    [SerializeField] GameObject shopShadow;

    [SerializeField] TMP_InputField nameInputField;
    

    public Image currentChar;

    Vector3 dfCharUIPos ;
    Vector3 dfShopUIPos;
    Vector3 dfConfirmUIPos;
    
    Vector3 dfSettingUIPos;


    

    public List<CharInventory> allChar = new List<CharInventory>();
    public List<CharInventory> myChar = new List<CharInventory>();
    
    public List<CharInventory> sellChar = new List<CharInventory>();
    public List<CharInventory> confirmChar = new List<CharInventory>();
    public List<GameObject> mail = new List<GameObject>();
    public List<GameObject> eventBanner = new List<GameObject>();

    public  List<int> randomN = new List<int>();

    public List<Button> shopButtons = new List<Button>();
    public CharData curretMyChar;
    public int mycharIndex =0;
    int confirmIndex=0;

    string confirmcharCode;

    public string playerName;
    public int howGold;
    public int howScore;

    

    [SerializeField] PlayerCharController playerCharController;

    private void Awake()
    {
        
        
        MainUpdate();

        
        dfCharUIPos = charSelectUI.GetComponent<Transform>().position;
        dfShopUIPos = shopUI.GetComponent<Transform>().position;
        dfConfirmUIPos = confirmUI.GetComponent<Transform>().position;
        
        dfSettingUIPos = settingUI.GetComponent<Transform>().position;

        currentCharImgPos = currentCharImgPos.GetComponent<Image>();
        playerCharController = playerCharController.GetComponent<PlayerCharController>();



        for (int i = 0; i < CharManager.data.Count; i++)
        {
            allChar.Add(new CharInventory(CharManager.data[i].charCode));
        }

        allChar[0].charOn = true;
        
        
        myCharUpdate();
        sellCharUpdate();
        RandomNumber();
        ShopButtonUpdate();
        CharChange();

        MailUpdate();

        playerName = "123";
        playerCharController.playChar = myChar[0].charData;

    }

    private void Update()
    {
        ShadowControl();
        UIMove();
        RandomNumber();


        
        currentCharImgPos.sprite = myChar[0].charData.charImage;
        

        


        
        
        if (randomN.Count < maxRanNum)
        {
            RandomPick();
            Debug.Log(randomN.Count);
        }
        
        
        if(randomN.Count == maxRanNum && maxRanNum!=0 && !shopfinish)
        {
            Shopping();
        }

        nameTxt.text = $"�г��� : {playerName}";




    }





    void myCharUpdate()
    {
        myChar.RemoveAll(p => true);
        for (int i = 0; i < allChar.Count; i++)
        {
            if (allChar[i].charOn)
            {
                myChar.Add(allChar[i]);
            }
        }
        
        
    }

    void sellCharUpdate()
    {
        sellChar.RemoveAll(p => true);
        for (int i = 0; i<allChar.Count; i++)
        {
            if (!allChar[i].charOn)
            {
                sellChar.Add(allChar[i]);
            }
        }
    }

    void ShopButtonUpdate()
    {
        shopButtons.RemoveAll(p => true);
        confirmChar.RemoveAll(p => true);

        switch (sellChar.Count)
        
        
        
        {
            case 0:
                shopUI.transform.GetChild(0).gameObject.SetActive(false);
                shopUI.transform.GetChild(1).gameObject.SetActive(false);
                shopUI.transform.GetChild(2).gameObject.SetActive(false);
                break;
            case 1:
                shopButtons.Add(shopUI.transform.GetChild(0).gameObject.GetComponent<Button>());
                shopUI.transform.GetChild(1).gameObject.SetActive(false);
                shopUI.transform.GetChild(2).gameObject.SetActive(false);


                break;
            case 2:
                shopButtons.Add(shopUI.transform.GetChild(0).gameObject.GetComponent<Button>());
                shopButtons.Add(shopUI.transform.GetChild(1).gameObject.GetComponent<Button>());
                shopUI.transform.GetChild(2).gameObject.SetActive(false);

                /*shopUI.transform.GetChild(2).gameObject.GetComponent<Image>().color = Color.clear;
                shopUI.transform.GetChild(2).gameObject.transform.GetChild(0).gameObject.SetActive(false);
                shopUI.transform.GetChild(2).gameObject.transform.GetChild(1).gameObject.SetActive(false);*/
                break;
            default:
                shopButtons.Add(shopUI.transform.GetChild(0).gameObject.GetComponent<Button>());
                shopButtons.Add(shopUI.transform.GetChild(1).gameObject.GetComponent<Button>());
                shopButtons.Add(shopUI.transform.GetChild(2).gameObject.GetComponent<Button>());
                break;




        }

        
    }



    void UIMove()
    {
        if (isCharSelect)
        {
            charSelectUI.transform.position = new Vector3(0, 0, 0);
        }
        else
        {
            charSelectUI.transform.position = dfCharUIPos;
        }
        if (isShop)
        {
            shopUI.transform.position = new Vector3(0, 0, 0);
        }
        else
        {
            shopUI.transform.position = dfShopUIPos;
        }
        if (isConfirm)
        {
            confirmUI.transform.position = new Vector3(0, 0, 0);
        }
        else
        {
            confirmUI.transform.position = dfConfirmUIPos;
        }
        if (isMail)
        {
            mailUI.SetActive(true);
        }
        else
        {
            mailUI.SetActive(false);
        }
        if (isSetting)
        {
            settingUI.transform.position = new Vector3(0, 0, 0);
        }
        else
        {
            settingUI.transform.position = dfSettingUIPos;
        }
    }
    
    void ShadowControl()
    {
        if (!isMain)
        {
            mainShadow.SetActive(true);
        }
        else
        {
            mainShadow.SetActive(false);
        }

        if (isConfirm)
        {
            shopShadow.SetActive(true);
        }
        else
        {
            shopShadow.SetActive(false);
        }
    }
    
    
    void Shopping()
    {
        
        for (int i = 0; i < shopButtons.Count; i++)
        {
            
            shopButtons[i].gameObject.GetComponent<Image>().sprite =
                sellChar[randomN[i]].charData.charImage;
            
            shopButtons[i].transform.GetChild(0).gameObject.GetComponent<Text>().text =
                sellChar[randomN[i]].charData.charName;
            
            shopButtons[i].transform.GetChild(1).gameObject.GetComponent<Text>().text =
                sellChar[randomN[i]].charData.charPrice.ToString();
            
            confirmChar.Add( sellChar[randomN[i]]);
            

        }

        shopfinish = true;
        //sellChar2�� 1�� 0���϶� ����


    }
    void RandomNumber()
    {
        switch (sellChar.Count) 
        {   case 0:
                maxRanNum = 0;
                break;
            case 1:
                maxRanNum = 1;
                break;
            case 2:
                maxRanNum = 2;
                break;
            default:
                maxRanNum = 3;
                break;

        }

    }

    
    
    void RandomPick()
    {
        //�ߺ��ȵǰ� �̱�
              
        
        int a = Random.Range(0, sellChar.Count);
                
                
        if (!randomN.Contains(a))
                {
                    randomN.Add(a);
                }
             
        
        
    }
    


    
    public void CharSelect()
    {
        isMain = false;
        isCharSelect = true;
        isShop = false;
        isConfirm = false;
        isMail = false;
        isSetting = false;

        

        
        
    }

    void CharChange()
    {
        currentChar.GetComponent<Image>().sprite = myChar[mycharIndex].charData.charImage;
    }
    //myChar���� �����ͼ� ������� �����ֱ� �翷 ��ư���� myChar[]�� ��������
    //���ڸ�ŭ ���� 0���� �ʱ�ȭ
    public void CharSelectRightArrow()
    {
        
        if (mycharIndex == myChar.Count-1)
        {
            mycharIndex =0;
        }
        else
        {
            mycharIndex++;
        }
        
        CharChange();
    }
    public void CharSelectLeftArrow()
    {

        if (mycharIndex == 0)
        {
            mycharIndex = myChar.Count-1;
        }
        else
        {
            mycharIndex--;
        }
        CharChange();
    }


    public void CharSelectGameStart()
    {
        MainUpdate();
        playerCharController.playChar = myChar[mycharIndex].charData;
        SceneManager.LoadScene(1);


    }

    public void ShopOpen()
    {
        

        isMain = false;
        isCharSelect = false;
        isShop = true;
        isConfirm = false;
        isMail = false;
        isSetting = false;

        

    }
    //��ư ���� �����ؼ� �̸� ���� ���� �־��ֱ�
    public void ConfirmOpen1()
    {
        isMain = false;
        isCharSelect = false;
        isShop = true;
        isConfirm = true;
        isMail = false;
        isSetting = false;

        confirmIndex = 1;
        confirmUI.transform.GetChild(0).gameObject.GetComponent<Image>().sprite =
            confirmChar[0].charData.charImage;
        confirmUI.transform.GetChild(1).gameObject.GetComponent<Text>().text =
            confirmChar[0].charData.charName+ confirmChar[0].charData.charPrice.ToString() 
            + confirmChar[0].charData.charDescript;




    }
    public void ConfirmOpen2()
    {
        isMain = false;
        isCharSelect = false;
        isShop = true;
        isConfirm = true;
        isMail = false;
        isSetting = false;

        confirmIndex = 2;
        confirmUI.transform.GetChild(0).gameObject.GetComponent<Image>().sprite =
            confirmChar[1].charData.charImage;
        confirmUI.transform.GetChild(1).gameObject.GetComponent<Text>().text =
            confirmChar[1].charData.charName + confirmChar[1].charData.charPrice.ToString()
            + confirmChar[1].charData.charDescript;

    }
    public void ConfirmOpen3()
    {
        isMain = false;
        isCharSelect = false;
        isShop = true;
        isConfirm = true;
        isMail = false;
        isSetting = false;

        confirmIndex = 3;
        confirmUI.transform.GetChild(0).gameObject.GetComponent<Image>().sprite =
            confirmChar[2].charData.charImage;
        confirmUI.transform.GetChild(1).gameObject.GetComponent<Text>().text =
            confirmChar[2].charData.charName + confirmChar[2].charData.charPrice.ToString()
            + confirmChar[2].charData.charDescript;

    }
    public void ConfirmOK()
    {
        //������ ������ charOn�� true�� �ٲٰ� ĳ������ �ʱ�ȭ
        
        switch (confirmIndex)
        {
            case 1:
                confirmcharCode = confirmChar[0].charData.charCode;
                
                break;
            case 2:
                confirmcharCode = confirmChar[1].charData.charCode;
                
                break;
            case 3:
                confirmcharCode = confirmChar[2].charData.charCode;
                
                break;
        }

        

        //confirmcharCode �� allchar���� �ڵ� ã�Ƽ� �������� on�� true;

        for (int i = 0; i < allChar.Count; i++)
        {
            if(confirmcharCode == allChar[i].charData.charCode)
            {
                allChar[i].charOn = true;
            }
        }
        
        randomN.RemoveAll(p=>true);
        sellCharUpdate();
        ShopButtonUpdate();
        
        ShopOpen();
        myCharUpdate();
        confirmChar.RemoveAll(p => true);

        shopfinish = false;
        






    }



    public void MailOpen()
    {
        isMain = true;
        isCharSelect = false;
        isShop = false;
        isConfirm = false;
        isMail = true;
        isSetting = false;
        

        
    }

    public void MailUpdate()
    {
        //mail ������ ������ �־��ش�.
        //mail.RemoveAll(p => true);
        GameObject[] mails= (GameObject[])Resources.LoadAll<GameObject>("Mail");
        for (int i = 0; i < mails.Length; i++)
        {
            mail.Add( Instantiate(mails[i]));
            
        }
        for (int i = 0; i < mail.Count; i++)
        {
            
            
            mail[i].transform.SetParent(mailParent.transform,false);
        }
        
    }

    public void EventUpdate()
    {
        GameObject[] events = (GameObject[])Resources.LoadAll<GameObject>("Event");
        for (int i = 0; i < events.Length; i++)
        {
            eventBanner.Add(Instantiate(events[i]));

        }
        for (int i = 0; i < mail.Count; i++)
        {


            mail[i].transform.SetParent(eventParent.transform, false);
        }

    }
    public void SettingOpen()
    {
        isMain = false;
        isCharSelect = false;
        isShop = false;
        isConfirm = false;
        isMail = false;
        isSetting = true;
    }
    public void SetName()
    {
        string newName;

        newName = nameInputField.text;

        playerName = newName;

        //�ؽ�Ʈ �޾ƿͼ� �� �̸��� ����

        
    }
    public void WipeScore()
    {
        //���� ������ ���� 0���� �ʱ�ȭ 
        bestScore = 0;
        Debug.Log(bestScore);
    }
    public void WipeGamedata()
    {
        //���δ� ã�Ƽ� �ʱ�ȭ?
        //�̸� ���� ĳ��������
        reset = true;
        playerName = "None";
        WipeScore();
        for (int i = 0; i < allChar.Count; i++)
        {
            allChar[i].charOn = false;
        }
        allChar[0].charOn = true;
        ShopButtonUpdate();
        myCharUpdate();
        sellCharUpdate();
        CharChange();

        MailUpdate();

        MainUpdate();

        reset = false;


        Debug.Log(playerName);
        Debug.Log(bestScore);
        Debug.Log(playerName);
    }

    
    
    public void MainUpdate()
    {
        isMain = true;
        isCharSelect = false;
        isShop = false;
        isConfirm = false;
        isMail = false;
        isSetting = false;
    }





}
