using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SoundManager : MonoBehaviour
{
    //private Dictionary<string, AudioClip> soundList = new Dictionary<string, AudioClip> ();

    //private GameObject soundPlayer;
    //  private void Awake()
    //{
    //    AudioClip[] sounds = Resources.LoadAll<AudioClip>("sounds");

    //    audioPlayer = Resources.Load<GameObject>("Prefabs/AudioPlayer")
    //}



}
