using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Coin : MonoBehaviour
{

    public Text txt;

    public int score;


    void Start()
    {

        score = 0;
        txt = GameObject.Find("ScoreShowTxt").GetComponent<Text>();
    }

    void OnTriggerEnter2D(Collider2D o)
    {
        if (o.gameObject.tag == "Coin")
        {
            print(o.gameObject.name);
            Destroy(o.gameObject);
            score += 10;
            txt.text = $"{score.ToString()} ��";
        }
    }


}

