using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Enemy : MonoBehaviour
{
    public Slider slider;

    Rigidbody2D rigid;

    private void Awake()
    {
        this.rigid = GetComponent<Rigidbody2D>();

        slider = GameObject.Find("SliderTime").GetComponent<Slider>(); 


        //Think();
    }

    private void Update()
    {
        transform.position += new Vector3(0, 0, 0) * Time.deltaTime;
    }

    public void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.CompareTag("Samurai"))
        {
            Debug.Log("������!");
            gameObject.SetActive(false);

        }
        else if (collision.CompareTag("BasicKnight"))
        {

            slider.value -= 10f;
            Debug.Log("�ε�����!");
            gameObject.SetActive(false);

        }
        else if (collision.CompareTag("MoonKnight"))
        {

            slider.value -= 10f;
            Debug.Log("�ε�����!");
            gameObject.SetActive(false);

        }
    }

    //void Think()
    //{
    //    this.rigid.velocity = new Vector2(-7, rigid.velocity.y);
    //}
    //public int nextMove;
    //private SpriteRenderer render;

    //private void Awake()
    //{
    //    this.rigid = GetComponent<Rigidbody2D>();

    //    Think();
    //}



    //private void FixedUpdate()
    //{
    //    this.rigid.velocity = new Vector2(nextMove, rigid.velocity.y);
    //    Vector2 frontVector = new Vector2(rigid.position.x + nextMove * .3f, rigid.position.y);
    //    RaycastHit2D rayhit = Physics2D.Raycast(frontVector, Vector3.down, 1, LayerMask.GetMask("Platform"));
    //    if (rayhit.collider == null)
    //        Turn();
    //}

    //private void Think()
    //{
    //    nextMove = Random.Range(-1, 2);
    //    if (nextMove != 0)
    //    {
    //        render.flipX = nextMove == 1;
    //    }

    //    float nextThinkTime = Random.Range(2f, 6f);
    //    Invoke("Think", nextThinkTime);
    //}

    //void Turn()
    //{
    //    nextMove += -1;
    //    render.flipX = nextMove == 1;
    //    CancelInvoke();
    //    Invoke("Think", 5);

    //}


}
