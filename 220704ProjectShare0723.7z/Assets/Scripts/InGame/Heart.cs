using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Heart : MonoBehaviour
{

    public Slider slider;

    private void Start()
    {
        slider = GameObject.Find("SliderTime").GetComponent<Slider>();
    }

    //private void Start()
    //{
    //    slider = GetComponent<Slider>();
    //}

    // Update is called once per frame
    void OnTriggerEnter2D(Collider2D heart)
    {
        //�߰��� �ȵ�
        if (heart.gameObject.tag == "Heart")
        {
            Destroy(heart.gameObject);
            Debug.Log("��Ʈ����");
            slider.value += 10f;
        }


    }
}
