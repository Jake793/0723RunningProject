using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class SliderTimer : MonoBehaviour
{

    [SerializeField] RectTransform FinishScreen;

    Slider slTimer;
    float fSliderBarTime;

    private void Start()
    {
        slTimer = GetComponent<Slider>();
    }

    private void Update()
    {
        if (slTimer.value > .0f)
        {
            Time.timeScale = 1;
            slTimer.value -= Time.deltaTime * 2;

        }
        else
        {
            Time.timeScale = 0;
            FinishScreen.anchoredPosition = Vector2.zero;
        }
    }
}
