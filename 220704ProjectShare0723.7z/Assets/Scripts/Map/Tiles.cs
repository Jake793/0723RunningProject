using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Tiles : MonoBehaviour
{
    public float speed;
    Vector3 moveVec;
    

    float leftPosX = 0f;
    float rightPosX = 0f;
    float xScreenHalfSize;
    float yScreenHalfSize;
    float x;
    void Start()
    {
        yScreenHalfSize = Camera.main.orthographicSize;
        xScreenHalfSize = yScreenHalfSize * Camera.main.aspect;

        //leftPosX = -(xScreenHalfSize * 2);
        //rightPosX = xScreenHalfSize * 2 * backgrounds.Length;
        PositionUpdate();
    }

    void Update()
    {
        moveVec.x -= speed * Time.deltaTime;
        transform.position= moveVec;
        
        if(transform.position.x < -140)
        {
            transform.position = new Vector3(287, 0, 0);
            PositionUpdate();
        }
    }
    void PositionUpdate()
    {
        moveVec = transform.position;
    }
}
