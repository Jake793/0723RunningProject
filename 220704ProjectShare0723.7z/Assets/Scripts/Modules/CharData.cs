using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CharData
{
    public string charCode;
    public string charName;
    public string charDescript;
    public int charPrice;

    
    public Sprite charImage;
    string eventKey;


    public CharData(string charCode, string charName, string charDsecript, int charPrice,string eventKey = null)
    {
        this.charCode = charCode;
        this.charName = charName;
        this.charDescript = charDsecript;
        this.charPrice = charPrice;
        
        this.charImage = Resources.Load<Sprite>($"CharImg/{charCode}");
        
        this.eventKey = eventKey;
        
    }
}
