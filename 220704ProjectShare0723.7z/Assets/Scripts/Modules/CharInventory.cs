using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CharInventory 
{
    
    public bool charOn;
    public CharData charData;
    

    public CharInventory(string code)
    {
        charData = CharManager.GetChar(code);
        charOn = false;
    }

    
    

}
